package controlers;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import Entities.credentialsC;
import dao.CredentialsDAO;

/**
 * Servlet implementation class Logincontroler
 */
@WebServlet("/Logincontroler")
public class Logincontroler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Logincontroler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String vlogin, vpassword;
		credentialsC c=null;
		
		vlogin=request.getParameter("tlogin");
		vpassword=request.getParameter("tpassword");
		
		c=CredentialsDAO.checkcrdentials(vlogin, vpassword);
		
		if(c==null)
		{
			request.setAttribute("ERROR", "Login ou Mot de passe incorrecte");
			request.getRequestDispatcher("Login.jsp").forward(request, response);
		}
		else
		{
			request.getSession().setAttribute("UTILISATEUR", c);
			request.getRequestDispatcher("Index.jsp").forward(request, response);
		}
		
		
		
	}

}
