package Controller;

import java.util.ArrayList;

import model.bo.Etudiant;
import model.dao.EtudiantDAO;

public class Control {
public static void EnregistrerNouveauEtudiant(String cne,String nom, String prenom){
	EtudiantDAO e=new EtudiantDAO("jdbc:mysql://localhost/SMI6","root","","com.mysql.jdbc.Driver");
	e.insererEtudiant(new Etudiant(cne,nom,prenom));
	
	
}
public static void ModifierEtudiant(String cne,String nom, String prenom){
	
	EtudiantDAO e=new EtudiantDAO("jdbc:mysql://localhost/SMI6","root","","com.mysql.jdbc.Driver");
	e.modifierEtudiant(new Etudiant(cne,nom,prenom));
	
}
public static void supprimerEtudiant (String cne) {
	
	EtudiantDAO e=new EtudiantDAO("jdbc:mysql://localhost/SMI6","root","","com.mysql.jdbc.Driver");
e.supprimerEtudiant(cne);
}
public static Etudiant chercherEtudiant(String cne){
	EtudiantDAO e=new EtudiantDAO("jdbc:mysql://localhost/SMI6","root","","com.mysql.jdbc.Driver");
return e.chercherEtudiant(cne);
	
	
}
public static ArrayList< Etudiant> chercherEtudiantParNom(String nom){

	
	EtudiantDAO e=new EtudiantDAO("jdbc:mysql://localhost/SMI6","root","","com.mysql.jdbc.Driver");

	return e.chercherEtudiantParNom(nom);

	
	
	
}

}