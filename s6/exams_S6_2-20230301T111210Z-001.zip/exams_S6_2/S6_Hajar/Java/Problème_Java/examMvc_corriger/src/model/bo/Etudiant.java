package model.bo ;
public class Etudiant {
private String cne ;
private String nom;
private String prenom;
public Etudiant(Etudiant e) {
	super();
	this.cne = e.cne;
	this.nom = e.nom;
	this.prenom = e.prenom;
}
public Etudiant(String cne, String nom, String prenom) {
	super();
	this.cne = cne;
	this.nom = nom;
	this.prenom = prenom;
}
public String getCne() {
	return cne;
}
public void setCne(String cne) {
	this.cne = cne;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public String getPrenom() {
	return prenom;
}
public void setPrenom(String prenom) {
	this.prenom = prenom;
}



}