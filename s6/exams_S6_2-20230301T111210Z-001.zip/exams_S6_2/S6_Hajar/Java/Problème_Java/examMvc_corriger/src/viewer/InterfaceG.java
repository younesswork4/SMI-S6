package viewer;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import Controller.Control;

public class InterfaceG extends Frame{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	TextField txtCNE, txtNom,txtPrenom;
	Button btnModifier;
	public InterfaceG(){
		
		this.setTitle("ModificationEtudiants");
		this.setBounds(100, 100, 300, 400);
		
		txtCNE= new TextField();txtCNE.setColumns(15);
		txtNom= new TextField();txtNom.setColumns(15);
		txtPrenom= new TextField();txtPrenom.setColumns(15);
		btnModifier=new Button("Modifier");
		btnModifier.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
			
				
				Control.ModifierEtudiant(txtCNE.getText(), txtNom.getText(), txtPrenom.getText());
			}
			
			
		});
Panel p=new Panel()	;
p.setLayout(new GridLayout(3,1));
Panel p1=new Panel();
p1.add(new Label("CNE:"));
p1.add(txtCNE);
p.add(p1);
Panel p2=new Panel();
p2.add(new Label("Nom:"));
p2.add(txtNom);
p.add(p2);
Panel p3=new Panel();
p3.add(new Label("Prenom:"));
p3.add(txtPrenom);
p.add(p3);
this.add(p,BorderLayout.CENTER);
Panel aide =new Panel();
aide.add(btnModifier);
this.add(aide,BorderLayout.SOUTH);
this.addWindowListener(new WindowListener() {

	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosed(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowClosing(WindowEvent arg0) {
		// TODO Auto-generated method stub
		System.exit(0);
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
});
this.setResizable(false);
		this.setVisible(true);
	}
}
