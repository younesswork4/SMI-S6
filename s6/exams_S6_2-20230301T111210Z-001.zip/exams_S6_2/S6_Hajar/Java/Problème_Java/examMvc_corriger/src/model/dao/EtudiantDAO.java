package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bo.Etudiant;

public class EtudiantDAO {
private Connexion connexion ;
public EtudiantDAO(String url, String login, String password, String driver) {
	
	connexion=new Connexion(url,login,password,driver);
	
	
}
public void insererEtudiant(Etudiant et) { 
	
	
	try {
		String  sql="insert into etudiants (cne,nom,prenom)values('"+et.getCne()+"','"+et.getNom()+"','"+et.getPrenom()+"')";
		Connection con=connexion.getConnexion();
		Statement st = con.createStatement();
		st.executeUpdate(sql);
		st.close();con.close();		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
public void modifierEtudiant (Etudiant et) {
	try {
		Connection con=connexion.getConnexion();
		String  sql="update etudiants set cne='"+et.getCne()+"',nom='"+et.getNom()+"',prenom='"+et.getPrenom()+"' where cne='"+et.getCne()+"'";
		
		Statement st = con.createStatement();
		st.executeUpdate(sql);
		st.close();con.close();		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
public void supprimerEtudiant (String cne) {
	
	try {
		String  sql="delete from etudiants where cne='"+cne+"'";
		Connection con=connexion.getConnexion();
		Statement st = con.createStatement();
		st.executeUpdate(sql);
		st.close();con.close();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
public Etudiant chercherEtudiant(String cne){
	try {
		String  sql="select * from etudiants where cne='"+cne+"'";
		Connection con=connexion.getConnexion();
		Statement st = con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		st.close();con.close();
		return new Etudiant(rs.getString("cne"),rs.getString("nom"),rs.getString("prenom"));
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return null;
	
}
public ArrayList<Etudiant> chercherEtudiantParNom(String nom){
	
	try {
		String  sql="select * from etudiants where nom='"+nom+"'";
		Connection con=connexion.getConnexion();
		Statement st = con.createStatement();
		ResultSet rs=st.executeQuery(sql);
		st.close();con.close();
		ArrayList<Etudiant> etudiants=new ArrayList<Etudiant>();
		while(rs.next())etudiants.add(new Etudiant(rs.getString("cne"),rs.getString("nom"),rs.getString("prenom")));
		
		
		return etudiants;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	return null;
	
	
	
}

}