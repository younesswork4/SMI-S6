package examMariage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import examMariage.Personne.D�jaMari�Exception;
import examMariage.Personne.MemeSexeException;


public class Groupe {
@SuppressWarnings("rawtypes")
private ArrayList liste;
@SuppressWarnings("rawtypes")
public Groupe() { liste = new ArrayList() ; 
	remplirListe();
 }
@SuppressWarnings("unchecked")
private void remplirListe(){
	 
	
		
		
		 try {
			 Connection con;
			 Statement st ;
			
			 Class.forName("com.mysql.jdbc.Driver");
			 String url="jdbc:mysql://localhost/mariage";
			con = DriverManager.getConnection(url, "root", "");
			 st = con.createStatement();
				String sql="select * from personnes ";
				ResultSet rs = st.executeQuery(sql);
				Personne personne;Sexe sexe;
						while(rs.next())
							
						{		
							
							if(rs.getString("sexe").equals("F"))sexe=Sexe.F;
						else sexe=Sexe.M;
							personne=new Personne(rs.getString("cin"),rs.getString("nom"),sexe);
							this.liste.add(personne);
		}
					 
					
					rs.close();
					st.close();
					con.close();
					
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
		
		
		
		
	
			
		 
		 
}
public IPersonne getPersonne(String cne){
	
	Personne personne=null;
	for(Object o : liste)
	{
		personne=(Personne)o;
		if(personne.getCin().equals(cne))return personne;
	}
	return null;
	
	
	
}
public int taille() {
	
	
	
	
	return liste.size();
}
public void afficherToutLesStatuts(){
	
	
	for(Object o : liste)
	{
	((Personne)o).afficherStatut();;
		
	}
	
}
public void MarierCelibataires(){
	for(int i=0;i<taille();i++)
		for(int j=i;j<taille();j++)
			try {
				((Personne)liste.get(i)).marier(((Personne)liste.get(j)));
			} catch (D�jaMari�Exception | MemeSexeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
}

@SuppressWarnings("unchecked")
public void ajouter(Personne p)
{
	 try {
		 Connection con;
		 Statement st ;
		
		 Class.forName("com.mysql.jdbc.Driver");
		 String url="jdbc:mysql://localhost/mariage";
		con = DriverManager.getConnection(url, "root", "");
		 st = con.createStatement();
		 String sql="insert into personnes (nom,cin,sexe) values('"+p.getNom()+"','"+p.getCin()+"','"+p.getSexe()+"')";		
		
		 
		 st.executeUpdate(sql);
				st.close();
				con.close();
	liste.add(p);			
	} catch (SQLException | ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}