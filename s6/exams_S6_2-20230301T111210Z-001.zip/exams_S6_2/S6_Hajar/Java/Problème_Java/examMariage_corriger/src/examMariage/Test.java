package examMariage;


public class Test {

	
	static public void  main(String[] args) {
	
		
		Groupe g=new Groupe();
		g.ajouter(new Personne("00100","sarah",Sexe.F));
		
	}
}
