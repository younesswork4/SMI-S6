package examMariage;



public class Personne implements IPersonne {
private String cin;
private String nom;
private Sexe sexe;
private Personne conjoint;
// On suppose que les getters/setters sont fournies en cas de besoin
//constructeur param�tr� 1 : pour une personne non encore mari�e



public Personne(String cin, String nom, Sexe sexe) {
	
	this.cin = cin; this.nom = nom; this.sexe = sexe;
	this.conjoint = null;
	
}


// constructeur param�tr� 2 : pour une personne mari�e



@Override
public String toString() {
	if(conjoint!=null)
	return "Personne [cin=" + cin + ", nom=" + nom + ", sexe=" + sexe + ", conjoint=" + conjoint.nom + "]";
	else 	return "Personne [cin=" + cin + ", nom=" + nom + ", sexe=" + sexe + ", est celibataire ]";

}


public Personne(String cin, String nom, Sexe sexe, Personne conjoint){
	
	
this.cin = cin; this.nom = nom; this.sexe = sexe;
this.conjoint = conjoint; //ici nous voulions garder r�f�rence au conjoint



}
// constructeur param�tr� 3


public Personne(String cin, String nom, Sexe sexe,String cinConjoint, String nomConjoint, Sexe sexeConjoint) {
	
	
	this.cin = cin; this.nom = nom; this.sexe = sexe;
	if(sexe!=sexeConjoint)
	this.conjoint = new Personne(cinConjoint,nomConjoint, sexeConjoint,this); 
	else this.conjoint=null;
	
	
}
//m�thodes


public void marier(Personne conjoint) throws D�jaMari�Exception, MemeSexeException {
	if(this.sexe==conjoint.getSexe())throw new MemeSexeException();
	if(this.conjoint!=null)throw new  D�jaMari�Exception();
	if(conjoint.getConjoint()!=null)throw new  D�jaMari�Exception();

	
	conjoint.conjoint=this;
	this.conjoint=conjoint;
}
public void divorcer() throws NonMari�Exception {
	
	if(this.conjoint==null)throw new NonMari�Exception();
	this.conjoint.conjoint=null;
	this.conjoint=null;
	
}

public String getCin() {
	return cin;
}
public void setCin(String cin) {
	this.cin = cin;
}
public String getNom() {
	return nom;
}
public void setNom(String nom) {
	this.nom = nom;
}
public Sexe getSexe() {
	return sexe;
}
public void setSexe(Sexe sexe) {
	this.sexe = sexe;
}
public Personne getConjoint() {
	return conjoint;
}
public void setConjoint(Personne conjoint) {
	this.conjoint = conjoint;
}
public void afficherStatut() { 
	
	
	if(this.conjoint != null)System.out.println(this.nom+" est mari�(e) � "+this.conjoint.nom);
	else System.out.println(this.nom+" est celibataire");
	
	
}
@SuppressWarnings("serial")
public class D�jaMari�Exception extends Exception  {

	public D�jaMari�Exception() {
		super("deja marier");
		// TODO Auto-generated constructor stub
				}

	/**
	 * 
	 */

	
	
}
@SuppressWarnings("serial")
public class MemeSexeException extends Exception  {

	public MemeSexeException() {
		super("meme sexe");
		// TODO Auto-generated constructor stub
				
	}

	
	
}
@SuppressWarnings("serial")
public class NonMari�Exception extends Exception  {

	public  NonMari�Exception() {
		super("non marier");
		// TODO Auto-generated constructor stub
		
	}

	
}




}