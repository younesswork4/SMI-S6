package examMariage;

import examMariage.Personne.D�jaMari�Exception;
import examMariage.Personne.MemeSexeException;
import examMariage.Personne.NonMari�Exception;

public interface IPersonne {
void marier(Personne conjoint) throws D�jaMari�Exception, MemeSexeException;
void divorcer() throws NonMari�Exception;
void afficherStatut();
}