package examMariage;

public enum Sexe { M, F }
