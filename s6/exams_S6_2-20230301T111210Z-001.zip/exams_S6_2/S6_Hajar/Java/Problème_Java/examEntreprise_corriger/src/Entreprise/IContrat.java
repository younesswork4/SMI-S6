package Entreprise;

public interface IContrat {
public String getCodeClient();
public String getCodeFournisseur();
}