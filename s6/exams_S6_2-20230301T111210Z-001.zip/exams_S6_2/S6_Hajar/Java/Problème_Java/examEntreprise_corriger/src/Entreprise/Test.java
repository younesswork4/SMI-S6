package Entreprise;

public class Test {

	
	
	public static void main(String args[]) {

		IContrat c=new Contrat(new Entreprise("100","hp"),new Entreprise("101","microsoft"));
		System.out.print(c);
		
	}
}
