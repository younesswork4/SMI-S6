package Entreprise;

public class Contrat implements IContrat{
private Entreprise client;
private Entreprise fournisseur;
public Contrat(Entreprise client, Entreprise fournisseur) {
this.client =new Entreprise(client);
this.fournisseur =new Entreprise(fournisseur);
}
public Contrat(String code1, String raisonSociale1, String code2, String
raisonSociale2) {
this.client =new Entreprise( code1,  raisonSociale1);
this.fournisseur = new Entreprise( code2,  raisonSociale2);
}
//on suppose que les Getters & Setters sont fournis
@Override
public String getCodeClient(){
return this.client.getCode();
}
@Override
public String getCodeFournisseur(){
	
	return this.fournisseur.getCode();
}
@Override
public String toString() {
return "client : "+client+" , fournisseur : "+fournisseur;

}
@Override
public boolean equals(Object obj) {
	
	Contrat other=(Contrat)obj;
return (this.client.equals(other.client) && this.fournisseur.equals(other.fournisseur));
}
}