package Entreprise;

public class Entreprise {
	
private String code;
private String raisonSociale;
public Entreprise(String code, String raisonSociale) {
this.code =code;
this.raisonSociale=raisonSociale;
}
public Entreprise(Entreprise entreprise) {
this.code =entreprise.code;
this.raisonSociale=entreprise.raisonSociale;
}
@Override
public String toString() {
return "raisonSociale : "+raisonSociale+", code : "+code;
}
@Override
public boolean equals(Object o)
{
	  if(o==null) return false;


  Entreprise e=(Entreprise)o;
   if(!code.equals(e.code))return false;
  
  return true;
}
public String getCode() {
	return code;
}
public void setCode(String code) {
	this.code = code;
}
public String getRaisonSociale() {
	return raisonSociale;
}
public void setRaisonSociale(String raisonSociale) {
	this.raisonSociale = raisonSociale;
}

}