package exam;

interface IElement {
public String getNom();
public String getNomComplet();

}
