package exam;

import javax.lang.model.element.Element;

public class Fichier implements IElement{

	
	private String nomFichier;
	private IElement parent;
	
	public IElement getParent() {
		return parent;
	}

	public void setParent(IElement parent) {
		this.parent = parent;
	}

	public Fichier(String nomFichier, IElement parent) {
		super();
		this.nomFichier = nomFichier;
		this.parent = parent;
	}

	public Fichier(String nomFichier) {
		super();
		this.nomFichier = nomFichier;
		parent=null;
	}

	@Override
	public String getNom() {
		// TODO Auto-generated method stub
		return nomFichier;
	}

	@Override
	public String getNomComplet() {
		// TODO Auto-generated method stub
		if(parent==null)return nomFichier;
		else
			return parent.getNomComplet()+"/"+this.nomFichier;
	}

}
