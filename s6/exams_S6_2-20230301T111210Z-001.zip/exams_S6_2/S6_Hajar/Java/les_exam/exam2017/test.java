package exam;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Dossier2 root=new Dossier2("root") ;  Dossier2 a=new Dossier2("a");
		Dossier2 b=new Dossier2("b");  Dossier2 c=new Dossier2("c");
		Dossier2 d=new Dossier2("d");
		Fichier2 f0=new Fichier2("f0");Fichier2 f1=new Fichier2("f1");
		Fichier2 f2=new Fichier2("f2");Fichier2 f3=new Fichier2("f3");
		Fichier2 f4=new Fichier2("f4");Fichier2 f5=new Fichier2("f5");
		root.ajouterElement(a);
		a.ajouterElement(b);b.ajouterElement(c);
		b.ajouterElement(d);
		root.ajouterElement(f0);c.ajouterElement(f1);
		b.ajouterElement(f3);c.ajouterElement(f2);d.ajouterElement(f4);
		d.ajouterElement(f5);
		root.dessinerHearchie();
	}

}
