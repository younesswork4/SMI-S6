package exam;

public abstract class Element {

	
	private String nom;
	private Element parent;
	public Element(String nom,Element parent) {
		this.nom=nom;
		this.parent=parent;
	}
		public String getNomComplet() {
			
			if(parent==null)return nom;
			else
				return parent.getNomComplet()+"/"+this.nom;
		}
		public String getNom() {
			return nom;
		}
		public void setNom(String nom) {
			this.nom = nom;
		}
		public Element getParent() {
			return parent;
		}
		public void setParent(Element parent) {
			this.parent = parent;
		}
		
		
	
}
