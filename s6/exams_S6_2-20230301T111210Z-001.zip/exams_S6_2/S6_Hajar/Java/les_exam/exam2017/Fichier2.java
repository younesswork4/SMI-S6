package exam;

public class Fichier2 extends Element {

	public Fichier2(String nom) {
		super(nom, null);
		// TODO Auto-generated constructor stub
	}

	
}
