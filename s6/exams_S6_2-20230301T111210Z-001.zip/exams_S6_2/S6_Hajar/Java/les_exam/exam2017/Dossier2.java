package exam;

import java.util.ArrayList;

public class Dossier2 extends Element{

	
	
	
		
		private ArrayList contenu;
		public Dossier2(String nom)
		{
			
			super(nom, null);
			
			
			contenu=new ArrayList();
			
			
			
		}
		public void ajouterElement(Element element)
		{
			contenu.add(element);
			element.setParent(this);
			
		}
		public void retirerElement(Element element)
		{
			contenu.remove(element);
			element.setParent(null);
		}
		public Element getElement(int index)
		{
			return (Element) contenu.get(index);
		}
		
		
		
	private	boolean autre(Dossier2 d,Element e)//si il suive un autre fichier
		{
			for(int i=0;i<d.contenu.size()-1;i++)
			{
				
				if( d.contenu.get(i)==e)return true;
				
			}
				
			return false;
		}
	private String dessinerLigne(Element e)//la ligne avant nom 
	{
		
		String s="";
	
		if(e.getParent()!=null)
		{
			
			
			int max=max((Dossier2)e.getParent())+2;
			
			
			
			if(e.getParent().getParent()!=null && autre((Dossier2)(e.getParent().getParent()),e.getParent()))
			{
				for(int i=0;i<max-1;i++)s=s+" ";
				
				
				
				return dessinerLigne(e.getParent())+"|"+s;
			}
			for(int i=0;i<max;i++)s=s+" ";
		return dessinerLigne(e.getParent())+s;
		}
		
		return s;
	}
private int	max(Dossier2 d )//plus long nom de fichier dans le dossier
	{
	
	int max =0;
	for(Object e : d.contenu)
	{
		if(max<((Element)e).getNom().length())max=((Element)e).getNom().length();
	}
			
		return max;
	
	
	}

		void dessinerHearchie()
		{
			System.out.println(dessinerLigne(this)+"|__"+this.getNom());
			for(Object e : contenu)
			{
				if(e instanceof Dossier2) ((Dossier2)e).dessinerHearchie();
				if(e instanceof Fichier2) System.out.println(dessinerLigne((Fichier2)e)+"|__"+((Fichier2)e).getNom());
			}
		}
		
}
