package exam;

import java.awt.List;
import java.util.ArrayList;

public class Dossier implements IElement {
private String nomDossier;
private IElement parent;
private ArrayList contenu;
public Dossier(String nomDossier)
{
	this.nomDossier=nomDossier;
	parent=null;
	contenu=new ArrayList();
	
	
	
}

public IElement getParent() {
	return parent;
}

public void setParent(IElement parent) {
	this.parent = parent;
}

@Override
public String getNom() {
	// TODO Auto-generated method stub
	return this.nomDossier;
}
@Override
public String getNomComplet() {
	// TODO Auto-generated method stub
	if(parent==null)return nomDossier;
	else return parent.getNomComplet()+"/"+nomDossier;
}
public void ajouterElement(IElement element)
{
	contenu.add(element);
	if(element instanceof Dossier)
	{
		((Dossier)element).parent=this;
	}
	else
	{
		((Fichier)element).setParent(this);
	}
	
}
public void retirerElement(IElement element)
{
	contenu.remove(element);
	if(element instanceof Dossier)
	{
		((Dossier)element).parent=null;
	}
	else
	{
		((Fichier)element).setParent(null);
	}
}
public IElement getElement(int index)
{
	return (IElement) contenu.get(index);
}


}
