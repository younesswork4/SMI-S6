
public class affiche  {
	
	
	public affiche(Object k)
	{
		
		System.out.println(k);
		
	}
	
	
	

}
