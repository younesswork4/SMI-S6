
public class Arbre {
	
	private int contenu;
	private Arbre filsGauche;
	private Arbre filsDroit;
	
	/****** partie 2 ******/
	private int taille;
	private int hauteur;
	public Arbre(int contenu) { // noeud sans fils
		this.contenu = contenu;
		this.filsGauche = null;
		this.filsDroit = null;
		
		}
		public Arbre(int contenu, Arbre filsGauche) { //noeud avec un seul fils
		this.contenu = contenu;
		this.filsGauche = filsGauche;
		this.filsDroit = null;
		
		
		}
		
		public Arbre(int contenu, Arbre filsGauche, Arbre filsDroit) { //avec 2 fils
			this.contenu = contenu;
			this.filsGauche = filsGauche;
			this.filsDroit = filsDroit;
			
			/******partie 2****/
			this.taille=this.calculerTaille();
			this.hauteur=this.calculerHauteur();
			
			}
	/* 1 */	public int calculerTaille() 
		{
			
			if(this.getFilsGauche()!= null && this.getFilsDroit()!=null)return this.getFilsGauche().calculerTaille() +1+this.getFilsDroit().calculerTaille();
			else if(this.getFilsGauche()!= null )return this.getFilsGauche().calculerTaille()+1;
			else if(this.getFilsDroit()!=null)return this.getFilsDroit().calculerTaille()+1;
			else return 1;
			
			
			
		}
	/* 2 */		public int calculerHauteur() {
			if(this.getFilsGauche()== null && this.getFilsDroit()==null)return 1;
			else if(this.getFilsGauche()== null )return this.getFilsDroit().calculerHauteur()+1;
			else if(this.getFilsDroit()==null)return this.getFilsGauche().calculerHauteur()+1;
			else if(this.getFilsGauche().calculerHauteur()  < this.getFilsDroit().calculerHauteur())return 1+this.getFilsDroit().calculerHauteur();
			else return this.getFilsGauche().calculerHauteur()+1;
			
		}
		
		@Override
		/* 3 */		public String toString() {
			
			
			
			if(this.getFilsGauche()!= null && this.getFilsDroit()!=null)return this.getContenu()+" "+ this.getFilsGauche().toString()+this.getFilsDroit().toString();
			else if(this.getFilsGauche()!= null )return this.getContenu()+" "+this.getFilsGauche().toString();
			else if(this.getFilsDroit()!=null)return this.getContenu()+" "+ this.getFilsDroit().toString();
			else return this.getContenu()+" ";
		}
		
		@Override
		/* 4 */		public boolean equals(Object obj) {
			
		
			if (getClass() != obj.getClass())
				return false;
			Arbre arb = (Arbre) obj;
			if (contenu != arb.contenu)
				return false;
			if (filsDroit == null) {
				if (arb.filsDroit != null)
					return false;
			} else if (!filsDroit.equals(arb.filsDroit))
				return false;
			if (filsGauche == null) {
				if (arb.filsGauche != null)
					return false;
			} else if (!filsGauche.equals(arb.filsGauche))
				return false;
			return true;
			
			
		}
		public int getContenu() {
			return contenu;
		}
		public void setContenu(int contenu) {
			this.contenu = contenu;
		}
		public Arbre getFilsGauche() {
			return filsGauche;
		}
		public void setFilsGauche(Arbre filsGauche) {
			this.filsGauche = filsGauche;
		}
		public Arbre getFilsDroit() {
			return filsDroit;
		}
		public void setFilsDroit(Arbre filsDroit) {
			this.filsDroit = filsDroit;
		}
		public int getTaille() {
			return this.taille;
		}
		/**** partie 2 ****/
		
		public int getHauteur() {
			return hauteur;
		}
		//pas de setter pour hauteur et taille 
		
		
		

}
