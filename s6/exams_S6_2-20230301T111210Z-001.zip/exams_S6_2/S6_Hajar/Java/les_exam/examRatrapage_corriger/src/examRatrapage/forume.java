package examRatrapage;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class forume extends Frame {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
TextField  txtCNE,txtNom,txtPrenom;
MyList lstEtudiants;
Button 	btnAjouter,btnAfficher;
	
	public forume()
	{
		this.setTitle("Etudiants");
		this.setBounds(100, 100, 600, 400);
		this.setLayout(new GridLayout(1,2));
		
		txtCNE=new TextField();txtCNE.setColumns(20);
		txtNom=new TextField();txtNom.setColumns(20);
		txtPrenom=new TextField();txtPrenom.setColumns(20);
		lstEtudiants=new MyList(15);
		btnAjouter=new Button("Ajouter");
		
		btnAjouter.addActionListener(new ActionListener()
				{

					@Override
					public void actionPerformed(ActionEvent arg0) {
						ajouter();
						
					}

					
			
			
				});
		
		btnAfficher=new Button("Afficher");
		btnAfficher.addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				afficher();
			}
	
	
		});
		Panel p1=new Panel();
		p1.setLayout(new BorderLayout());
			Panel p11=new Panel();
			p11.setLayout(new GridLayout(3,1));
	 Panel p111=new Panel(); 
	 p111.add(new Label("CNE"))	 ;
	 p111.add(this.txtCNE);
	 p11.add(p111);
	 Panel p112=new Panel(); 
	 p112.add(new Label("Nom"))	 ;
	 p112.add(this.txtNom);
	 p11.add(p112);
	 Panel p113=new Panel(); 
	 p113.add(new Label("Prenom"))	 ;
	 p113.add(this.txtPrenom);
	 p11.add(p113);
		p1.add(p11,BorderLayout.CENTER);
		p1.add(new Panel(),BorderLayout.NORTH);
		p1.add(this.btnAjouter,BorderLayout.SOUTH);
		Panel p2=new Panel();
		p2.setLayout(new BorderLayout());
		Panel aide2=new Panel();
		aide2.add(this.lstEtudiants);
		p2.add(aide2,BorderLayout.CENTER);
		p2.add(new Panel(),BorderLayout.NORTH);
	Panel aide=new Panel();
	aide.add(this.btnAfficher);
		p2.add(aide,BorderLayout.SOUTH);
		this.add(p1);
		this.add(p2);
		
		
		
		
		
		
		this.addWindowListener(new WindowListener() {

			@Override
			public void windowActivated(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowClosed(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowClosing(WindowEvent arg0) {
				// TODO Auto-generated method stub
				System.exit(0);
			}

			@Override
			public void windowDeactivated(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowDeiconified(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowIconified(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void windowOpened(WindowEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
			
		});
		this.setResizable(false);
		this.setVisible(true);
	}
	
	public void ajouter()
	{
		this.lstEtudiants.AjouterEtudiant(new Etudiant(this.txtCNE.getText(),this.txtNom.getText(),this.txtPrenom.getText()));
		
		
	}
	public void afficher()
	{
		
		Etudiant e=lstEtudiants.getSelectedEtudiant();
		if(e!=null)
		{
this.txtCNE.setText(e.getCNE());
this.txtNom.setText(e.getNom());
this.txtPrenom.setText(e.getPrenom());
			
		}
		
	}
}
