package examRatrapage;

import java.awt.List;
import java.util.HashMap;
import java.util.Map;

public class MyList extends List{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
@SuppressWarnings("rawtypes")
private Map collectionEtudiants;
@SuppressWarnings("rawtypes")
public MyList() {
	
	collectionEtudiants =new HashMap();
	
	
}
@SuppressWarnings("rawtypes")
public MyList(int n) {
	
	super(n);
	collectionEtudiants =new HashMap();
}
@SuppressWarnings("unchecked")
public void AjouterEtudiant(Etudiant etudiant){
collectionEtudiants.put(etudiant.getCNE(), etudiant);
this.add(etudiant.getCNE());


}
public Etudiant getSelectedEtudiant(){

	
	
	return (Etudiant) collectionEtudiants.get(this.getSelectedItem());
}
}