package aa;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class UDao implements IDao {

	@Override
	public int AddUser(User u) {
		
		DBInteraction.connect();
		String sql="insert into users (log,pass,role) values('"+u.getLog()+"','"+u.getPass()+"','"+u.getRole()+"')";
		int nb=DBInteraction.Maj(sql);
		DBInteraction.disconnect();
		return nb;
	}

	@Override
	public int AddUser(String log, String pass, String role) {
		
		User u=new User(log, pass, role);
		int nb=AddUser(u);
		return nb;
	}

	@Override
	public int deleteUser(int id) {
		DBInteraction.connect();
		String sql="delete from users where id="+id;
		int nb=DBInteraction.Maj(sql);
		DBInteraction.disconnect();
		return nb;
	}

	@Override
	public User FindUser(int id) {
		User u=null;
		DBInteraction.connect();
		String sql="select * from users where id="+id;
		ResultSet rs = DBInteraction.Select(sql);
		try {
			if(rs.next())
			{
				u=new User();
				u.setId(rs.getInt(1));
				u.setLog(rs.getString(2));
				u.setPass(rs.getString(3));
				u.setRole(rs.getString(4));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		DBInteraction.disconnect();
		return u;
	}

	@Override
	public User Authentificat(String log, String pass) {
		User u=null;
		DBInteraction.connect();
		String sql="select * from users where log='"+log+"' and pass='"+pass+"'";
		ResultSet rs = DBInteraction.Select(sql);
		try {
			if(rs.next())
			{
				u=new User();
				u.setId(rs.getInt(1));
				u.setLog(rs.getString(2));
				u.setPass(rs.getString(3));
				u.setRole(rs.getString(4));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		DBInteraction.disconnect();
		return u;
	}

	@Override
	public int UpdateUser(int id, User u) {
		DBInteraction.connect();
		String sql="update users set log='"+u.getLog()+"' ,pass='"+u.getPass()+"', role='"+u.getRole()+"' where id="+id;
		int nb=DBInteraction.Maj(sql);
		DBInteraction.disconnect();
		return nb;
	}

	@Override
	public List<User> AllUsers() {
		List<User> us=new ArrayList<>();
		
		DBInteraction.connect();
		String sql="select * from users ";
		ResultSet rs = DBInteraction.Select(sql);
		try {
			while(rs.next())
			{
				User u=new User();
				u.setId(rs.getInt(1));
				u.setLog(rs.getString(2));
				u.setPass(rs.getString(3));
				u.setRole(rs.getString(4));
				us.add(u);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		DBInteraction.disconnect();
		
		
		return us;
	}

	
	
}
