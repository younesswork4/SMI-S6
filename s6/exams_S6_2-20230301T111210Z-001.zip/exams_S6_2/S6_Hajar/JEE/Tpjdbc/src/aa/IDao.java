package aa;
import java.util.List;


public interface IDao {

	
	public int AddUser(User u);
	public int AddUser(String log,String pass,String role );
	public int deleteUser(int id);
	public User FindUser(int id);
	public User Authentificat(String log,String pass);
	public int UpdateUser(int id,User u);
	public List<User> AllUsers();
	
}
