package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aa.UDao;
import aa.User;

/**
 * Servlet implementation class Usr
 */
@WebServlet("/Usr")
public class Usr extends HttpServlet {
	private static final long serialVersionUID = 1L;
   UDao um;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Usr() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		um=new UDao();
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String act = request.getParameter("btn");
		
		if(act.equals("connect"))
		{
		User uu = um.Authentificat(request.getParameter("log"), request.getParameter("pass"));
	//	System.out.println(uu.getLog());
		if(uu!=null)
		{
			out.print("Bonjour Mr  "+uu.getLog()+"<hr>");
		List<User> us = um.AllUsers();
		out.print("<table border='2' width='60%' bgcolor='gold'>");
		for(int i=0;i<us.size();i++)
		{
			out.print("<tr>");
			out.print("<td>"+us.get(i).getId()+"</td>");
			out.print("<td>"+us.get(i).getLog()+"</td>");
			out.print("<td>"+us.get(i).getRole()+"</td>");
			
			out.print("</tr>");
		}
		out.print("</table>");
		}
		else
			{
			out.print("<h1>login ou password incorrect..........");
			
			}
		}else
		{
			if(act.equals("inscription"))
			{
				um.AddUser(request.getParameter("log"), request.getParameter("pass"), request.getParameter("role"));
				response.sendRedirect("auth.html");
			}
		}
	}

}
