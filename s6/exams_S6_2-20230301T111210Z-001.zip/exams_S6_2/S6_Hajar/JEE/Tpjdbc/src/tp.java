


public class tp {

	public static void main(String[] args) {
		
		UDao um=new UDao();
		
		
		um.AddUser("bbb", "bbb", "admin");
	}

}
