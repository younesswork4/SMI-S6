package test;

import java.util.List;

import javax.swing.plaf.basic.BasicBorders.MarginBorder;

import DAO.ProduitImpl;
import Entity.Produit;
import Utils.DB;

public class test {

	public static void main(String[] args) {

		Produit p1 = new Produit();
		p1.setDesignation("produit 1");
		p1.setPrix_achat(new Float(400));
		p1.setPrix_vente(new Float(500));
		p1.setQteStock(new Integer(40));

		Produit p2 = new Produit();
		p2.setDesignation("produit 2");
		p2.setPrix_achat(new Float(780));
		p2.setPrix_vente(new Float(550));
		p2.setQteStock(new Integer(340));

		Produit p3 = new Produit();
		p3.setDesignation("produit 3");
		p3.setPrix_achat(new Float(300));
		p3.setPrix_vente(new Float(500));
		p3.setQteStock(new Integer(20));

		ProduitImpl daoProduit = new ProduitImpl();

		if (daoProduit.AjouterProduit(p1))
			System.out.println("p1 => ok");
		if (daoProduit.AjouterProduit(p2))
			System.out.println("p2 => ok");
		if (daoProduit.AjouterProduit(p3))
			System.out.println("p3 => ok");

		
		
		System.out.println("----------------Liste des Produits------------------------");
		List<Produit> ls = daoProduit.getAllProduit();

		for (int i = 0; i < ls.size(); i++) {

			System.out.println("ID : " + ls.get(i).getID());
			System.out.println("Designation : " + ls.get(i).getDesignation());
			System.out.println("Prix_achat : " + ls.get(i).getPrix_achat());
			System.out.println("Prix_vente : " + ls.get(i).getPrix_vente());
			System.out.println("QteStock : " + ls.get(i).getQteStock());
			System.out.println("----------------------------------------");

		}

	}
}
