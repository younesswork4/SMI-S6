package com.tld;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Isitld extends TagSupport{
	
	int row,col;
	
	public void setRow(int row) {
		this.row = row;
	}

	public void setCol(int col) {
		this.col = col;
	}

	@Override
	public int doStartTag() throws JspException {
		
		JspWriter out = pageContext.getOut();
		try {
			out.print("<h1>je suis une Tag</h1>");
			out.print("<table border='2' bgcolor='gold'>");
			for(int i=0;i<row;i++)
			{
				out.print("<tr>");
				for(int j=0;j<col;j++)
					out.print("<td><input type='text' value='"+i+","+j+"'/> </td>");
				out.print("</tr>");
				
			}
			out.print("</table>");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.doStartTag();
	}

}
