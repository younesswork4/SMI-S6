package com.tld;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import aa.UDao;
import aa.User;

public class UserTld extends TagSupport{
	UDao  um=new UDao();
	String sup,mod;
	
	public void setSup(String sup) {
		this.sup = sup;
	}

	public void setMod(String mod) {
		this.mod = mod;
	}

	@Override
	public int doStartTag() throws JspException {
		
		JspWriter out = pageContext.getOut();
		ServletRequest req = pageContext.getRequest();
		List<User> us = um.AllUsers();
		
		try {
			out.print("<table class='utld'>");
			out.print("<thead><th>ID</th><th>Login</th><th>Role</th><th></th></thead>");
			for(User u : us)
			{
				out.print("<tr>");
				out.print("<td>"+u.getId()+"</td>");
				out.print("<td>"+u.getLog()+"</td>");
				out.print("<td>"+u.getRole()+"</td>");
				if(sup.equals("oui"))
				{
				out.print("<td><a href='?id="+u.getId()+"'>supprimer</a> - <a href=''>Modifier</a></td>");
				}
				out.print("</tr>");
				
			}
			
			
			
			out.print("</table>");
			if(req.getParameter("id")!=null)
			{
				int id=Integer.parseInt(req.getParameter("id"));
				um.deleteUser(id);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return super.doStartTag();
	}

}
