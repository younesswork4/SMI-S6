package com;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Abc extends TagSupport{

	int row,cel;
	
	public void setRow(int row) {
		this.row = row;
	}

	public void setCel(int cel) {
		this.cel = cel;
	}

	@Override
	public int doStartTag() throws JspException {
		
		JspWriter out = pageContext.getOut();
		try {
			out.print("<h1>Bonjour</h1>");
			out.print("<table border='1' bgcolor='gold'>");
			for(int i=0;i<row;i++)
			{
				out.print("<tr>");
				for(int j=0;j<cel;j++)
				{
					out.print("<td><input type='button' value='"+i+","+j+"'/> </td>");
				}
				out.print("</tr>");
			}
			
			out.print("</table>");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return super.doStartTag();
	}
}
