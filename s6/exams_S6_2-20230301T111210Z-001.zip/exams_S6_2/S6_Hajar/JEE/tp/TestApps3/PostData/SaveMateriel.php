<?php
session_start();

   
    require_once("../DAO/MaterielManager.php");
    require_once("../Pages/Validator.php");
    
    extract($_POST);//Pour travailler directement par les variables $name et $pass
    //Filtration des donnees
        $validator =  new Validator(); 
        $validator->remove_html($_POST);
        $validator->remove_Espace($_POST);
        $validator->Add_slashes($_POST);    
       
    //validation des donnees dans le cas d'email ...
   
    $CM = new MaterielManager();
    $nbligne = $CM->AddMateriel($_POST);

      header("Location:../Pages/Admin/gestionMateriels/listMateriel.php");

 
?>