<?php
session_start();

    require_once("../DAO/CompteManager.php");
    require_once("../Pages/Validator.php");
    
    extract($_POST);//Pour travailler directement par les variables $name et $pass
    //Filtration des donnees
        $validator =  new Validator(); 
        $validator->remove_html($_POST);
        $validator->remove_Espace($_POST);
        $validator->Add_slashes($_POST);    
       
    //validation des donnees dans le cas d'email ...
   
    $CM = new CompteManager();
    $existe = $CM->existePseudo($Pseudo);
    
    if($existe==1){
       
        echo "le compte exite deja :p !! ";
        
    }else{
        
        $l = $CM->AddCompte($_POST);
        echo "ajout avec succee id : ".$l;
    }
    
 
?>