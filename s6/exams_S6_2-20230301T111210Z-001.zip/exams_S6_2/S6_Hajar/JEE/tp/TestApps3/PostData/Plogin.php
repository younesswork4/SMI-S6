<?php
session_start();

    require_once("../DAO/CompteManager.php");
    require_once("../Pages/Validator.php");
    
    extract($_POST);//Pour travailler directement par les variables $name et $pass
    //Filtration des donnees
        $validator =  new Validator(); 
        $validator->remove_html($_POST);
        $validator->remove_Espace($_POST);
        $validator->Add_slashes($_POST);    
    //var_dump($data);
    //validation des donnees dans le cas d'email ...
   
    $CM = new CompteManager();
    $compte = $CM->Authentifier($name,$pass);
    
    if($compte){

        //header("Location:../Pages/$compte->nameRole/profil.php");
        $_SESSION["compte"]= (array)$compte;
        echo $compte->nameRole;
        
    }else{

        //$_SESSION['error']="Compte saisie est invalid !!";
        echo "error";
    }
?>