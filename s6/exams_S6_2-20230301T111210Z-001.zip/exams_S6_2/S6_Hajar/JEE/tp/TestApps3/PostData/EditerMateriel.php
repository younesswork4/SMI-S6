<?php
session_start();

    require_once("../DAO/CompteManager.php");
    
    extract($_POST);//Pour travailler directement par les variables $name et $pass
       
    //var_dump($_POST);
    $MM = new MaterielManager();
    $nb = $CM->modifierMateriel($_POST);
    if($nb == 1){   
      header("Location:../Pages/Admin/gestionMateriels.php");
    }
?>