<?php
session_start();

    require_once("../DAO/CompteManager.php");
    
    extract($_POST);//Pour travailler directement par les variables $name et $pass
       
    //extraire les id 
    $id_comptes = explode("/",$id); 
    //var_dump($id_comptes);
    $CM = new CompteManager();
    $nb = $CM->deleteCompte($id_comptes);
    
    echo $nb;
?>