<?php
session_start();

    require_once("../DAO/MaterielManager.php");
    
    extract($_POST);//Pour travailler directement par les variables $name et $pass
       
    //extraire les id 
    $id_Materiels = explode("/",$id); 
    $CM = new MaterielManager();
    $nb = $CM->deleteMateriel($id_Materiels);
    
    echo $nb;
?>