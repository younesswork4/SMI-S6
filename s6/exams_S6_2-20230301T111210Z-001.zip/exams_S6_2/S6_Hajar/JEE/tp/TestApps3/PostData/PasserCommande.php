<?php
session_start();

    require_once("../DAO/CommandeManager.php");
    
    extract($_POST);//Pour travailler directement par les variables $name et $pass
    extract($_SESSION);

    //extraire les id 
    $CM = new CommandeManager();
    $idcmd = $CM->PasserCommande($_POST,$compte['id']);
    
    echo $idcmd;
?>
