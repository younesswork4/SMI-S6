<?php

	class Role{

		public $id,$nameRole,$levelRole;
		public function __construct(){/*...*/}

	}

?>