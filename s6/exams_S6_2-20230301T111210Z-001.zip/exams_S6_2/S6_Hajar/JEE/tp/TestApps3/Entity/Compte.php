<?php

	
	class Compte
	{
                public function __tostring(){
                    return "[".$this->nom.", ".$this->prenom.", ".$this->nameRole." ... ]";
                }
		public $id,$nom,$prenom,$pseudo,$password,$nameRole;

/*		public function __construct(){$this->msg="salame yassine :D !!";}
*/
	}
?>