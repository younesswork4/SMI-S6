    
function validateData(data){
	//console.log(data);
	for(key in data){

		if(!data[key])
		return false;	
	}	
	return true;
}

function getDesignError(msg){

    var selector = 'div.panel-footer';
    
	document.querySelector('div.panel').className = "panel panel-danger";
	document.querySelector(selector).className = "panel-footer";
	document.querySelector(selector).innerText = msg;
	document.querySelector(selector).style.color = "red";
        document.querySelector(".btn").className = "btn btn-danger";
        document.querySelector("div.panel").style.boxShadow = "0px 0px 18px red";
}


function SendData(data){

		//send data from dynamic forms :D 
		formData = new FormData();
		formData.append("name",data.name);
		formData.append("pass",data.pass);
                
                
		//maintenant on va envoyer les donnees

		var xhr = new XMLHttpRequest();//l'objet xhr et celui qui contient les methodes necessaire pour envoyer les donnes

		//hna khasni ngol lhadake xhr 3afac declancher liya evenement dyale la communication avec la page server.php

		xhr.onreadystatechange = function(){

			if(xhr.readyState ===4 && xhr.status === 200){

				//recuperer la reponse :D
				var res = xhr.responseText;
                                
                                if(res===" error")
                                {
                                    getDesignError("mot de pass ou username not found !! ");
                                }
                                else{
                                    res = res.substr(1,res.length);
                                    window.location = res+"/profil.php";
                                }
                        }    

                }
			
		xhr.open("POST","../PostData/Plogin.php");//ovrir le fichier destinataire
		xhr.send(formData);//envoyer data :D 



}

function Onsubmit(){
    
    //recuperation des donnes :D 
	var name = document.querySelector('input[name="name"]').value;
	var pass = document.querySelector('input[name="pass"]').value;

	//console.log("name : "+name+" pass : "+pass);

	//validation des donnees :D 
	var donnes  = {name:name,pass:pass};
	var valider = validateData(donnes);
        
	//Test Sur La validation des donnee
	if(valider){
		SendData(donnes);				
	}else{		
		getDesignError("Error Les Champs pas valide !!");		
	}
        
	return false;
}