$(function(){
   
   
   $("form").submit(function(){
        
        Onsubmit();
        
        return false;
        
   });  
    
});
    
function validateData(data){
	//console.log(data);
	for(key in data){

		if(!data[key])
		return false;	
	}	
	return true;
}








function SendData(data){

		//send data from dynamic forms :D 
		formData = new FormData();
		formData.append("Prenom",data.Prenom);
        formData.append("Nom",data.Nom);
        formData.append("Pseudo",data.Pseudo);
        formData.append("role",data.role);
        formData.append("pass",data.pass);
                
		//maintenant on va envoyer les donnees

		var xhr = new XMLHttpRequest();//l'objet xhr et celui qui contient les methodes necessaire pour envoyer les donnes

		//hna khasni ngol lhadake xhr 3afac declancher liya evenement dyale la communication avec la page server.php

		xhr.onreadystatechange = function(){

			if(xhr.readyState ===4 && xhr.status === 200){

				//recuperer la reponse :D
				var res = xhr.responseText;
                    alert(res);
                    $('form').each(function(){
                        this.reset();
                    });
                }    

            }
			
		xhr.open("POST","../../../PostData/SaveCompte.php");//ovrir le fichier destinataire
		xhr.send(formData);//envoyer data :D 



}

function Onsubmit(){
    
    //recuperation des donnes :D 
	var nom = document.querySelector('input[name="Nom"]').value;
	var prenom = document.querySelector('input[name="Prenom"]').value;
    var Pseudo = document.querySelector('input[name="Pseudo"]').value;
	var role = document.querySelector('select[name="role"]').value;
	var pass = document.querySelector('input[name="pass"]').value;
        
	//console.log("name : "+name+" pass : "+pass);

	//validation des donnees :D 
	var donnes  = {Nom:nom,Prenom:prenom,Pseudo:Pseudo,role:role,pass:pass};
        
        //console.log(donnes);
        
        
        var valide = validateData(donnes);
        
        if(valide){
            
            SendData(donnes);
            
        }else{
            
            alert("Veuillez remplir les champs !! ");
        }
}
