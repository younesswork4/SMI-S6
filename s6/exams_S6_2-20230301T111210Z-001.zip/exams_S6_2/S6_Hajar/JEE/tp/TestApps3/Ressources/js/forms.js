$(function(){
   
    $("form[name='myForm'").find("input").click(function(){
      
        $("div#panel").attr("class","panel panel-primary");
        $("div#panel").css("box-shadow","0px 0px 18px deepskyblue"); 
        $("div.panel-footer").attr("class","panel-footer hide");
        $("button.btn").attr("class","btn btn-primary");
    });
    
    makeCenterWithParent($("div.Usr-info-continer"),$("p.info"),10); 
    makeCenterWithParent($("div.Usr-info-continer"),$("div.usr"),8);
    
    
});

function makeCenterWithParent(parent,child,delta){
    
    var left = $(parent).width()/2 - $(child).width()/2 - delta;
    $(child).css("left",left+"px");
}

function DisplayMenu(){
    
    $(".dmenu").click(function(){
      
    });
}