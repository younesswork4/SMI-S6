$(function() {
 
   
 
$("a#supp").click(function() {

            var id="";

            $("table.comptes").find("tr").each(function() {

                if($(this).find("td:eq(0)").find("input[type='checkbox']").is(":checked")) {

                        id += "/"+$(this).find("td:eq(1)").text();
                        //console.log(id);
                } 

            });
            if(id !==""){
                sendData(id);
            }else{
                alert("Aucune ligne est cocher !! ");
            }
    });
    
	
});




function sendData(id){
           
    //le fichier ajax.js est executer man fichier fine mincluder fel head ya3ni fe addProfesseur.php
        $.post("../../../PostData/DeleteCompte.php",{id:id},function(data) {
           // var space = "<br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
           //$("body").append(space+data); 
           alert("suppression avec succee de "+data+" ligne !! ");
           window.location.href = " ";
                
        });
}