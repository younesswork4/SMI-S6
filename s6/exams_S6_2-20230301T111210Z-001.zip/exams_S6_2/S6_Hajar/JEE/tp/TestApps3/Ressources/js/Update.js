var cancel="";
$(function() {
 
   
   $("a").click(function(){
       
       var action  = $(this).text();
       var icon = '<i class="glyphicon glyphicon-edit" ></i>';
        
       //alert(action);
       
       if(action===" Annuler"){
           
           CancelAction($(this),icon);
           
       }else if(action===" Editer"){
            
           UpdateAction($(this),icon);
           
       }else if(action===" Commander"){
           
         CommmanderAction($(this),icon);
         
       }else{
          window.location.href=" ";
       }       
       
   });
   
});

function CancelAction(currentElementt,icon){
    
    $("table.comptes").removeClass("Update-Style");
    $("input[type='checkbox']").fadeIn();
    if(cancel==="cmd"){
         $(currentElementt).html(icon+" Commander");
    }else{
         $(currentElementt).html(icon+" Editer");
    }
   
    $("#supp").show();
}

function appendDataToModal(info_account){
        
    $(".modal-body").find("input[name='id']").val(info_account.id);
    $(".modal-body").find("input[name='Prenom']").val(info_account.pren);
    $(".modal-body").find("input[name='Nom']").val(info_account.nom);
    $(".modal-body").find("input[name='Pseudo']").val(info_account.pseudo);
    $(".modal-body").find("input[name='role']").val(info_account.role);
}

function appendDataToModalCMD(idmateriel){
        
    $(".modal-body").find("input[name='id']").val(idmateriel);
}


function TranslateData(ligne){
    
    var id =  $(ligne).find("td:eq(1)").text();
    var nom =  $(ligne).find("td:eq(2)").text();
    var pren =  $(ligne).find("td:eq(3)").text();
    var pseudo =  $(ligne).find("td:eq(4)").text();
    var role =  $(ligne).find("td:eq(5)").text();
    var account_info = {id:id,nom:nom, pren:pren, pseudo:pseudo,role:role};   
    //console.log(account_info);
    appendDataToModal(account_info);
    return id;
}

function UpdateAction(currentElementt,icon){
     
    $("table.comptes").addClass("Update-Style");
    $("input[type='checkbox']").fadeOut();
      $(currentElementt).html(icon+" Annuler");
 
        $("table.comptes").find("tr").click(function(){
            if($(currentElementt).text()==" Annuler"){
                TranslateData($(this));
                $("#UpdateModel,#myModal").modal('show');
            }
         });
    $("a#supp").hide();
    cancel="update";
}


function CommmanderAction(currentElementt,icon){
    
    $("table.comptes").addClass("Update-Style");
    $("input[type='checkbox']").fadeOut();
    $(currentElementt).html(icon+" Annuler");
 
        $("table.comptes").find("tr").click(function(){
            if($(currentElementt).text()==" Annuler"){
               var id = TranslateData($(this));
                appendDataToModalCMD(id);
                $("#CommandeModel").modal('show');
            }
         });
   
    $("a#supp").hide();
    cancel="cmd";
}