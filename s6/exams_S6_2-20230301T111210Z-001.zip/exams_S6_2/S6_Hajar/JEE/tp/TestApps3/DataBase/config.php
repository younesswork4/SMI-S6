<?php

 	define("DB_HOST","localhost");
	define("DB_NAME","gespinfo");
	define("DB_USER","root");
	define("DB_PASSWD","");

?>