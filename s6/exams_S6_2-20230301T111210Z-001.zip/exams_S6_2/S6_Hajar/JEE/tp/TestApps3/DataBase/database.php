 <?php

 	require_once('config.php');//inclure le fichier nécessaires(require) config.php seulement une fois(once)   


 	class database{

 		private static $mysql=null;

 		public static function deconnect(){

 			self::$mysql=null;
 		}

 		public static function connect(){

 			if(self::$mysql == NULL){

 				//PHP DATA OBJECT 
 				self::$mysql = new PDO("mysql:host=localhost;dbname=GestionParcInfo","root","");
 			}

 			return self::$mysql;
 		}

 		

 	}
 ?>
