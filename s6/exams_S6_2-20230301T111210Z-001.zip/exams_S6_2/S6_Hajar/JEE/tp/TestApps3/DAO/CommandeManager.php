<?php
	
	require_once('../DataBase/database.php');//La class qui contient l'objet de connexion 

	require_once('../Entity/Compte.php');
	

	class CommandeManager{


		public function __construct()
		{
			# code...
		}

		public function PasserCommande($data,$iduser){


    
                    extract($data);
                   
                    $cn =  database::connect();

                    //inserer la commande 	
					$query =$cn->prepare("insert into commande values(Null,?,?,?)");

					$query->bindParam(1,$iduser);
					$query->bindParam(2,$id);
					$query->bindParam(3,$qute);
                    $query->execute(); 

				//recuperer l'id du commande inserer
				 $id_cmd= $cn->lastInsertId();	    
				
                                 
                                

               database::deconnect();	
                                 
			    return $id_cmd;

			
                }
                
      
}
?>