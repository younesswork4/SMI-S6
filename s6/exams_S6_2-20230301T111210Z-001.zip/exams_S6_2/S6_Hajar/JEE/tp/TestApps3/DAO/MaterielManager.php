<?php
	
	require_once('../DataBase/database.php');//La class qui contient l'objet de connexion 

	require_once('../Entity/Compte.php');
	

	class MaterielManager{


		public function __construct()
		{
			# code...
		}

                public function AddMateriel($materiel){
                    
                    extract($materiel);
                   
                     $cn =  database::connect();

                            //inserer le compte 	
				$query =$cn->prepare("insert into materiel values(Null,?,?,?,?)");

					$query->bindParam(1,$dateAquis);
					$query->bindParam(2,$garantie);
					$query->bindParam(3,$marque);
                                        $query->bindParam(4,$model);
                                        
                                        
                                        $query->execute(); 

				//recuperer l'id du compte inserer
				 $id_materiel = $cn->lastInsertId();	    
				
                                 
                                

                            database::deconnect();	
                                 
			    return $id_materiel;

			
                }
                                
        public function deleteMateriel(array $id_materiels){
            
                $cn =  database::connect();
                
                $nbligne="";
                for ($i = 1; $i < count($id_materiels); $i++) {
                     
                    $query =$cn->prepare("delete from materiel where id=?"); 
                    $query->bindParam(1,$id_materiels[$i]);                                                             
                    $query->execute();
                    $nbligne = $nbligne." ".$id_materiels[$i];
                }
                 
                database::deconnect();
                    
                return $nbligne;
        }
        
        public function modifierCompte(array $info_materiel){
            
                extract($info_materiel);
                
                $cn =  database::connect();
                    
                    $query = $cn->prepare("update materiel set dateAquis=?, garantie=?,marque=?,modele=? where id=?");
                    $query->bindParam(1,$dateAquis);
                    $query->bindParam(2,$garantie);
                    $query->bindParam(3,$marque);
                    $query->bindParam(4,$modele);
                    $query->bindParam(6,$id);
                    $nbligne = $query->execute();
                    
                database::deconnect();	
                    
                return $nbligne;
            
        }        
}
?>