<?php
	
	require_once('../DataBase/database.php');//La class qui contient l'objet de connexion 

	require_once('../Entity/Compte.php');
	

	class CompteManager{


		public function __construct()
		{
			# code...
		}

		public function Authentifier($log,$pass){


			$cn =  database::connect();


				$query = $cn->prepare(" 
							SELECT c.id,nom,prenom,pseudo,password,nameRole
							from compte c,role r 
							where pseudo=:log 
							and password=:pass 
                            and c.idrole=r.id
                                    ");

				$query->bindValue(':log',$log);
				$query->bindValue(':pass',$pass);
				$query->execute();


				$query->setFetchMode(PDO::FETCH_CLASS,'Compte');

			    $compte = $query->fetch();

			   database::deconnect();	
                          
                           return $compte;
		}
                
                public function getListCompte(){
                    
                    $cn =  database::connect();


				$query = $cn->prepare(" 
							SELECT id,nom,prenom,nom,pseudo,namerole
                                                        from compte c,role rs
                                                        where c.idrole = r.id
                                                    ");

				
				$query->execute();


				$query->setFetchMode(PDO::FETCH_CLASS,'Compte');

			    $comptes = $query->fetch();

                            database::deconnect();	
                            
			    return $comptes;

			
                }

                public function AddCompte($compte){
                    
                    extract($compte);
                   
                     $cn =  database::connect();

                            //inserer le compte 	
				$query =$cn->prepare("insert into compte values(Null,?,?,?,?,?);");

					$query->bindParam(1,$Nom);
					$query->bindParam(2,$Prenom);
					$query->bindParam(3,$Pseudo);
                    $query->bindParam(4,$pass);
                    $query->bindParam(5,$role);
                                        
                                        
                                        $query->execute(); 

				//recuperer l'id du compte inserer
				 $id_compte = $cn->lastInsertId();	    
				
                                 
                                

                            database::deconnect();	
                                 
			    return $id_compte;

			
    }
                
                public function existePseudo($pseudo){
                    
                    $cn =  database::connect();

                            //inserer le compte 	
                                $pseudo = strtoupper($pseudo);
				$query =$cn->prepare("select count(*) from compte where UPPER(pseudo)=?");
                                $query->bindParam(1,$pseudo);
				                                                                               
                                $query->execute();

                                $existe = $query->fetchColumn();
				
                                				
                    database::deconnect();	
                    
                    return $existe;
                }
	
                
        public function deleteCompte(array $id_comptes){
            
                $cn =  database::connect();
                
                $nbligne="";
                for ($i = 1; $i < count($id_comptes); $i++) {
                     
                    $query =$cn->prepare("delete from compte where id=?");
                    $query->bindParam(1,$id_comptes[$i]);                                                             
                    $query->execute();
                    $nbligne = $nbligne." ".$id_comptes[$i];
                }
                 
                database::deconnect();
                    
                return $nbligne;
        }
        
        public function modifierCompte(array $info_compte){
            
                extract($info_compte);
                
                $cn =  database::connect();
                    
                    $query = $cn->prepare("update compte set nom=?, prenom=?,pseudo=?,password=?,idrole=? where id=?");
                    $query->bindParam(1,$Nom);
                    $query->bindParam(2,$Prenom);
                    $query->bindParam(3,$Pseudo);
                    $query->bindParam(4,$pass);
                    $query->bindParam(5,$role);
                    $query->bindParam(6,$id);
                    $nbligne = $query->execute();
                    
                database::deconnect();	
                    
                return $nbligne;
            
        }        
}
?>