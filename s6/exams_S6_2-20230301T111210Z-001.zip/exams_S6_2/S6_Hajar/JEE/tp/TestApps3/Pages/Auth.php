<?php

	class Auth{

		public static function isLogged(){

			if( isset($_SESSION["compte"]) && isset($_SESSION['compte']['password']) 
										   && isset($_SESSION['compte']['pseudo']) )
			{
				return true;
			}

			
		}
		public static function isRolePage(){

			if(self::isLogged()==true)
			{
				self::redirectTo($_SESSION["compte"]["role"]."/profil.php");

			}else{

				return false;
			}
		}
		public static function redirectTo($path){

			header("Location:".$path);
		}
	}


?>