
	<h3 class="h3"><i class="glyphicon glyphicon-th"></i> Gestion des Comptes</h3>

	<div class="btn-group" role="group">
            <a href="listCompte.php" class="btn btn-default">Liste des comptes</a>
	</div>

	<div class="">
			<h4 class="h4"><i class="glyphicon glyphicon-list"></i> Ajouter Compte</h4>
				<form action="" method="POST">
					<table class="table table-striped">
						<tr>
                            <td>Prenom</td><td><input type="text" class="form-control" name="Prenom"  required /></td>
						</tr>
						<tr>
                            <td>Nom</td><td><input type="text" class="form-control" name="Nom"  required /></td>
						</tr>
						<tr>
                           <td>Pseudo</td><td><input type="text" class="form-control" name="Pseudo"  required /></td>
						</tr>
						<tr>
                            <td>Role</td><td>
                            <select name="role" id="role" class="form-control">
                                                            <option value="1">ADMIN</option>
                                                            <option value="3">USER</option>
                                                            <option value="4">MAGAZINIER</option>
                                                            <option value="2">DIRECTEUR</option>
                                                        </select>
                                                    </td>
</tr>°
						<tr>
                                                    <td>Mot de passe</td><td><input type="password" class="form-control"  name="pass" required /></td>
						</tr>
						<tr>
                                                        <td></td>
							<td>
                                                            <input type="submit" class="btn btn-default" value="Enregistrer" style="margin-right:5px;"/>
                                                            <input type="reset" class="btn btn-default" value="Annuler"/>
							</td>
						</tr>
					</table>
				</form>
	</div>