<?php
session_start();
require_once '../../templates/template.php';
require_once('../../Auth.php');
require_once '../../../Database/database.php';
extract($_SESSION);
if (Auth::isLogged() == false) {
    Auth::redirectTo("../../login.php");
}
$param = array("Jforms","JSupp","JUpdate");

?>

