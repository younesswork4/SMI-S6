 
	<h3 class="h3"><i class="glyphicon glyphicon-th"></i> Gestion des Materiels</h3>

	<div class="btn-group" role="group">
            <a href="listMateriel.php" class="btn btn-default">Lister des Materiels</a>
	</div>

	<div class="">
			<h4 class="h4"><i class="glyphicon glyphicon-list"></i> Ajouter Materiel</h4>
				<form action="../../../PostData/SaveMateriel.php" method="POST">
					<table class="table table-striped">
						<tr>
                                                    <td>Date Aquise</td><td><input type="text" class="form-control" name="dateAquis"  required /></td>
						</tr>
						<tr>
                                                    <td>Modele</td><td><input type="text" class="form-control" name="model"  required /></td>
						</tr>
						<tr>
                                                    <td>Marque</td><td><input type="text" class="form-control" name="marque"  required /></td>
						</tr>
						<tr>
                                                    <td>Garantie</td><td>
                                                        <select name="garantie" id="role" class="form-control">
                                                            <option value="1">1 ans</option>
                                                            <option value="3">2 ans</option>
                                                            <option value="4">3 ans </option>
                                                        </select>
                                                    </td>
						</tr>
						<tr>
                                                        <td></td>
							<td>
                                                            <input type="submit" class="btn btn-default" value="Enregistrer" style="margin-right:5px;"/>
                                                            <input type="reset" class="btn btn-default" value="Annuler"/>
							</td>
						</tr>
					</table>
				</form>
	</div>