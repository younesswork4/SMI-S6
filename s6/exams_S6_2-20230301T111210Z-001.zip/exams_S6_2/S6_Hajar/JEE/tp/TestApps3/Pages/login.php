<?php
session_start();
require_once 'Auth.php';
require_once 'templates/template.php';
extract($_SESSION);
if(Auth::isLogged()==true) {Auth::redirectTo($compte['nameRole']."/profil.php");}
$params = array("Jscript","Jforms","Clogin");
?>


<html>  
        <link rel='stylesheet' href='../Ressources/css/bootstrap.css' />
        <link rel='stylesheet' href='../Ressources/css/login.css' />

        <script  src="../Ressources/js/jquery.js" ></script>
        <script  src="../Ressources/js/forms.js" ></script>        
        <script  src="../Ressources/js/script.js" ></script>

	<body id="body">
		<!-- Global Class -->
		<div id=container class="container">
			<div class="logo"></div>
			<div id=panel class="panel panel-primary">
				<div class="panel-heading">Login</div>
				<div class="panel-body">
					<form name="myForm" method="post" ><!-- action="../PostData/Plogin.php" -->
						<!-- User -->
						<div class="input-group">
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-user"></span>
							</span>
							<input type="text" class="form-control input-sm" placeholder="username" name="name"/>
						</div><br>

						<!-- Password -->
						<div class="input-group">
							<span class="input-group-addon">
								<span class="glyphicon glyphicon-lock"></span>
							</span>
							<input type="password" class="form-control input-sm" placeholder="password" name="pass"/>
						</div><br>

						<!-- Submit -->
                         <center><button id=submit onclick="return Onsubmit();"class="btn btn-primary">Connexion</button></center>
					</form>
				</div>
				<div class="panel-footer hide"></div>
			</div>
		</div>
	</body>
</html>

