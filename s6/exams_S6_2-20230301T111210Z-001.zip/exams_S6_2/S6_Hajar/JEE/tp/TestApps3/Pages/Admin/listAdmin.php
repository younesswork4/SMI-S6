<?php
session_start();
require_once '../templates/template.php';
require_once('../Auth.php');
require_once '../../Database/database.php';
extract($_SESSION);
if(Auth::isLogged()==false)Auth::redirectTo("../login.php");
else extract($_SESSION);
$param = array("Jforms","JSupp","JUpdate");

?>

<html>
    <head>
        <?php template::head($param);?>
    </head>
    <body>
        <?php template::getHeader($compte['nom']." ".$compte['prenom']);?>

        <div class="menu-continer">
            <?php include("AdminTemplate/menu_admin.php");?>
        </div>
        <div class="content-continer">
            <?php include("AdminTemplate/content_listCompte.php")?>
        </div>
       
    </body>
</html>