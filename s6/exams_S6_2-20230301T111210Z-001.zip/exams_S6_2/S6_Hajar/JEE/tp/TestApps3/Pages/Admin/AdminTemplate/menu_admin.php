<?php

define('GC','gestionComptes');
define('GM','gestionMateriels');
define('GCMD','gestionCommandes');

function getMenu($pathChoise){

    switch ($pathChoise){
    
        
        case "acceuil":{
            $path = array("./",GC."/",GC."/",GM."/",GM."/",GCMD."/");  
        }break;
        case "compte":{
            $path = array("../","./","./","../".GM."/","../".GM."/","../".GCMD."/");
        }break;
        case "materiel":{
            $path = array("../","../".GC."/","../".GC."/","./","./","../".GCMD."/");
        }break;
        case "commande":{
            $path = array("../","../".GC."/","../".GC."/","../".GM."/","../".GM."/","./");
        }break;
    }
    
echo "<div class='Usr-info-continer'>
                <div class='usr'></div>
                <p class='info'>ADMINISTRATOR </p>
            </div>
            <div class='menu'>
                <header><span><i class='glyphicon glyphicon-th-list'></i>  Menu</span></header> 
                <ul>
                    <li><a href='".$path[0]."profil.php'><i class='glyphicon glyphicon-home'></i> Acceuil</a></li>
                    <li><a href='".$path[1]."listCompte.php'><i class='glyphicon glyphicon-list-alt'></i> Liste Compte</a></li> 
                    <li><a  href='".$path[2]."AddCompte.php'><i class='glyphicon glyphicon-user'></i> Ajouter Compte</a></li>
                    <li><a href='".$path[3]."listMateriel.php'><i class='glyphicon glyphicon-list-alt'></i> Liste Materiel</a></li>
                    <li><a  href='".$path[4]."addMateriel.php'><i class='glyphicon glyphicon-user'></i> Ajouter Materiel</a></li>
                    <li><a href='".$path[5]."listCmd.php'><i class='glyphicon glyphicon-tasks'></i> Consulter mes commandes</a></li>
                </ul>";    
}