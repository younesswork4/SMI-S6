<?php
define('PATH_RESSOURCES',"../../../Ressources/"); 
define('PATH_R',"../../Ressources/"); 

require_once 'header.php';

class template {
    
    public static function imporFilesForProfile(){
        
        echo "<link rel='stylesheet' href='".PATH_R."css/bootstrap.css' />";
        echo "<link rel='stylesheet' href='".PATH_R."css/main.css' />";
        echo "<link rel='stylesheet' href='".PATH_R."js/jquery.js' />";
        echo "<link rel='stylesheet' href='".PATH_R."js/bootstrap.js' />";
        echo "<link rel='stylesheet' href='".PATH_R."js/forms.js' />";
        
    }
    private static function default_files(){
        
        self::createCssPATH("bootstrap");
        self::createCssPATH("main");
        self::createJsPATH("jquery");
        self::createJsPATH("bootstrap");
    }
    
    private static function  createCssPATH($file){
        echo "<link rel='stylesheet' href='".PATH_RESSOURCES."css/".$file.".css' />";
    }
    
    private static function  createJsPATH($file){      
        echo "<script src='".PATH_RESSOURCES."js/".$file.".js'></script>";
    }
    
    public static function head(array $params){
       
        self::default_files();
        
        foreach ($params as $f){
            if($f[0]=='J'){
                self::createJsPATH(substr($f,1));
            }
            else if($f[0]=='C'){
               self::createCssPATH(substr($f,1));
            }
        }
    } 
    public static function getHeader($fullName,$path="../../"){
    
       PRINT_HEADER($fullName,$path);
    }
    
    
  
}





?>