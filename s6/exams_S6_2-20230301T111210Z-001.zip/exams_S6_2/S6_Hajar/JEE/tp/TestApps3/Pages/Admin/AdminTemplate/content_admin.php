
            <h3 class="h3"><i class="glyphicon glyphicon-th"></i> Liste des Comptes</h3>
            <div class="btn-group" role="group">
              <a href="addCompte.php" class="btn btn-default">Nouveau compte</a>
            </div>

                <div>
                        <form method="POST">
                                <table class="table table-striped">
                                        <tr>
                                              <th></th><th>NUMERO</th><th>NOM</th><th>PRENOM</th><th>PSEUDO</th><th>ROLE</th>
                                        </tr> 
                                     <?php 
                                              $cn =  database::connect();


				$query = $cn->prepare(" 
							SELECT c.id,nom,prenom,pseudo,namerole 
                                                        FROM compte c
                                                        INNER JOIN role r
                                                        ON r.id= c.idrole
                                                    ");

				
				$query->execute();


			    $comptes = $query->fetchAll(PDO::FETCH_ASSOC);
                                        for($i=0;$i<count($comptes);$i++) {
                                         ?>
                                        <tr>
						<td><input type="checkbox" /></td>
						<td><?php echo $comptes[$i]["id"]; ?></td>
						<td><?php echo $comptes[$i]["nom"]; ?></td>
						<td><?php echo $comptes[$i]["prenom"]; ?></td>
						<td><?php echo $comptes[$i]["pseudo"]; ?></td>
                                                <td><?php echo $comptes[$i]["namerole"]; ?></td>
                                        </tr>
                                        <?php
                                        }
                                            database::deconnect();	
                                     ?>
                                </table>
                        </form>
                </div>	

                <a href="#" style="margin-right:10px" class="btn btn-default"><i class="glyphicon glyphicon-edit" ></i> Editer</a>
                <a href="#" class="btn btn-default btn-delete"><i class="glyphicon glyphicon-share" ></i> Supprimer</a>

	