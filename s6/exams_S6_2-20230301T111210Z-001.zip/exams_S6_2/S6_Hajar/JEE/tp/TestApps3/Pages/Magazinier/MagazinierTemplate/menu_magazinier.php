  <div class="Usr-info-continer">
                <div class="usr"></div>
                <p class="info">MAGAZINIER </p>
            </div>
            <div class="menu">
                <header><span><i class="glyphicon glyphicon-th-list"></i>  Menu</span></header> 
                <ul>
                    <li><a href=""><i class="glyphicon glyphicon-home"></i> Acceuil</a></li>
                    <li><a href=""><i class="glyphicon glyphicon-list-alt"></i> Liste Materiel</a></li>
                    <li><a href=""><i class="glyphicon glyphicon-education"></i> Passer Commande</a></li>
                    <li><a href=""><i class="glyphicon glyphicon-book"></i> Imprimer Bon Entree </a></li>
                    
                </ul>
            </div>