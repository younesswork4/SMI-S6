            <h3 class="h3"><i class="glyphicon glyphicon-th"></i> Liste des Materiels</h3>
            <div class="btn-group" role="group">
              <a href="addMateriel.php" class="btn btn-default">Nouveau Materiel</a>
            </div><br/><br/>
            <div class="list-table">
                        <form method="POST">
                                <table class="table table-striped comptes" >
                                        <tr>
                                            <th></th><th>NUMERO</th><th>DATE AQUIS</th><th>GARANTIE</th><th>MARQUE</th><th>MODELE</th>
                                        </tr> 
                                        <?php 
                                                $cn =  database::connect();
                                                $query = $cn->prepare(" 
                                                           SELECT * 
                                                           FROM materiel
                                                 ");
                                                $query->execute();


                                                 $comptes = $query->fetchAll(PDO::FETCH_ASSOC);
                                                 for($i=0;$i<count($comptes);$i++) {
                                                    ?>
                                                    <tr>
                                                            <td><input type="checkbox" /></td>
                                                            <td><?php echo $comptes[$i]["id"]; ?></td>
                                                            <td><?php echo $comptes[$i]["dateAquis"]; ?></td>
                                                            <td><?php echo $comptes[$i]["garantie"]; ?></td>
                                                            <td><?php echo $comptes[$i]["marque"]; ?></td>
                                                            <td><?php echo $comptes[$i]["modele"]; ?></td>
                                                    </tr>
                                                    <?php
                                                    }
                                            database::deconnect();	
                                     ?>
                                </table>
                        </form>
                </div>	

                <a  id="update" style="margin-right:10px" class="btn btn-default"><i class="glyphicon glyphicon-edit" ></i> Editer</a>
                <a  id="commander" style="margin-right:10px" class="btn btn-default"><i class="glyphicon glyphicon-edit" ></i> Commander</a>
                <a id="supp" class="btn btn-default btn-delete"><i class="glyphicon glyphicon-share" ></i> Supprimer</a>
               
                <?php include_once("modal.php");
                      getModel("UpdateModel","Modifier Un Materiel");  
                      getModel("CommandeModel","Passer Un Commnade");  
                      
                ?>