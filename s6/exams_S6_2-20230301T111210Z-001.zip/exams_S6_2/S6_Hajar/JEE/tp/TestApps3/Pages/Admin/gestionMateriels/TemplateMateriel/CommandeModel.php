
			<h4 class="h4"><i class="glyphicon glyphicon-list"></i> Taper Votre Commande</h4>
				<form action="../../../PostData/PasserCommande.php" method="POST">
					<table class="table table-striped">
						<tr>
                            <td>Quantite du produit materiel : </td><td><input name="qute" type="number" min="1" class="form-control"></td>
                            <input name="id" type="hidden"></td>
						</tr>
						<tr>
                                                        <td></td>
							<td>
                                <input type="submit" class="btn btn-default" value="passer La commande" style="margin-right:5px;"/>
                                <input type="reset" class="btn btn-default" value="Annuler"/>
							</td>
						</tr>
					</table>
				</form>