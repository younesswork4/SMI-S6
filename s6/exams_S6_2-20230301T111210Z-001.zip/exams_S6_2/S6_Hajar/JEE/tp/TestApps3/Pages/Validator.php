<?php

    class Validator{
        
        private $error;

        public function __construct(){
            $this->error=0;
        }
                
        //LES VALIDATORS
        public function validate_length($min,$max,$item){
            
            (strlen($item)>$min && strlen($max)<$max)? $this->error=$this->error:$this->error++; 
        }
        public function cmp_items($item1,$item2){
            ($item1 === $item2) ? $this->error= $this->error : $this->error++;
        }
        public function validate_email(){
            filter_var($email,FILTER_VALIDATE_EMAIL) ? $this->error= $this->error : $this->error++;
        }
        //LES FILTRES 
        public function remove_html(&$items){
            foreach ($items as $key=>$val){
                $items[$key] = strip_tags($val);
            }
        }
        public function remove_Espace(&$items){
             foreach ($items as $key=>$val){
                $items[$key] = trim($val);
            }
        }
        public function Add_slashes(&$items){
             foreach ($items as $key=>$val){
                $items[$key] = addslashes($val);
            }
        }
        
        public function getError(){return $this->error;}
    }
?>