<div class="Usr-info-continer">
                <div class="usr"></div>
                <p class="info">UTILISATEUR </p>
            </div>
            <div class="menu">
                <header><span><i class="glyphicon glyphicon-th-list"></i>  Menu</span></header> 
                <ul>
                    <li><a href=""><i class="glyphicon glyphicon-home"></i> Acceuil</a></li>
                    <li><a href=""><i class="glyphicon glyphicon-list-alt"></i> Liste Compte</a></li>
                    <li><a href=""><i class="glyphicon glyphicon-education"></i> Ajouter Compte</a></li>
                    <li><a href=""><i class="glyphicon glyphicon-book"></i> Rechercher Compte</a></li>
                    <li><a href=""><i class="glyphicon glyphicon-tasks"></i> Supprrimmer Compte</a></li>
                </ul>