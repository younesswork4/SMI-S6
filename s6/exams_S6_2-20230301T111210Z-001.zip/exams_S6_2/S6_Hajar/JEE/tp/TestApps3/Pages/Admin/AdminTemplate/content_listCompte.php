
            <h3 class="h3"><i class="glyphicon glyphicon-th"></i> Liste des Comptes</h3>
            <div class="btn-group" role="group">
              <a href="addCompte.php" class="btn btn-default">Nouveau compte</a>
            </div>
            <div class="list-table">
                        <form method="POST">
                                <table class="table table-striped comptes" >
                                        <tr>
                                              <th></th><th>NUMERO</th><th>NOM</th><th>PRENOM</th><th>PSEUDO</th><th>ROLE</th>
                                        </tr> 
                                     <?php 
                                              $cn =  database::connect();


                                              $query = $cn->prepare(" 
							SELECT c.id,nom,prenom,pseudo,namerole 
                                                        FROM compte c
                                                        INNER JOIN role r
                                                        ON r.id= c.idrole
                                                        order by c.id
                                              ");

				
                                              $query->execute();


                                              $comptes = $query->fetchAll(PDO::FETCH_ASSOC);
                                              for($i=0;$i<count($comptes);$i++) {
                                     ?>
                                        <tr>
						<td><input type="checkbox" /></td>
						<td><?php echo $comptes[$i]["id"]; ?></td>
						<td><?php echo $comptes[$i]["nom"]; ?></td>
						<td><?php echo $comptes[$i]["prenom"]; ?></td>
						<td><?php echo $comptes[$i]["pseudo"]; ?></td>
                                                <td><?php echo $comptes[$i]["namerole"]; ?></td>
                                        </tr>
                                        <?php
                                        }
                                            database::deconnect();	
                                     ?>
                                </table>
                        </form>
                </div>	

                <a  id="update" style="margin-right:10px" class="btn btn-default"><i class="glyphicon glyphicon-edit" ></i> Editer</a>
                <a id="supp" class="btn btn-default btn-delete"><i class="glyphicon glyphicon-share" ></i> Supprimer</a>
               
                <div id="myModal" class="modal fade" role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Editer le compte </h4>
                      </div>
                      <div class="modal-body">
                          <?php include("forms.php");?>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>

                  </div>
                </div>
          