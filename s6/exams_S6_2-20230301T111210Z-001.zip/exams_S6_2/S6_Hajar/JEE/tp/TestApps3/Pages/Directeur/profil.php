<?php
session_start();
require_once '../templates/template.php';
require_once('../Auth.php');
extract($_SESSION);
if(Auth::isLogged()==false){Auth::redirectTo("../login.php");}
if($compte['nameRole']!="Directeur"){
    Auth::redirectTo("../".$compte['nameRole']."/profil.php");
} 
?>

<html>
<head>
    <?php template::imporFilesForProfile();?>
</head>
<body>
    <?php template::getHeader($compte['nom']." ".$compte['prenom'],"../");?>
    
   <div class="menu-continer">
       <?php
       			include("DirecteurTemplate/menu_directeur.php");
      	 		getMenu("acceuil");
       ?>
   </div>
    <div class="content-continer2">
        <h1 class="title"><span class="bien">BIEN</span><span class="venue">VENUE</span></h1>
    </div>

</body>
</html>