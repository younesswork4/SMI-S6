
            <h3 class="h3"><i class="glyphicon glyphicon-th"></i> Mes Commandes</h3>
            <br>
            <div class="list-table">
                        <form method="POST">
                                <table class="table table-striped comptes" >
                                        <tr>
                                              <th></th><th>NUMERO</th><th>Marque</th><th>Modele</th>
                                        </tr> 
                                     	<?php 
                                              $cn =  database::connect();


                                              $query = $cn->prepare("
                                              						  SELECT c.id,marque,modele,qute
                                              						  FROM commande c, materiel m
                                              						  WHERE c.idmateriel = m.id
                                              						");

				
                                              $query->execute();


                                              $commandes = $query->fetchAll(PDO::FETCH_ASSOC);
                                              for($i=0;$i<count($commandes);$i++) {
			                                  ?>
			                                   		<tr> 	
														<td><?php echo $commandes[$i]["id"];?></td>
														<td><?php echo $commandes[$i]["marque"];?></td>
														<td><?php echo $commandes[$i]["modele"];?></td>
														<td><?php echo $commandes[$i]["qute"];?></td>
			                                        </tr>
		                                      <?php
		                                      }	

                                              database::deconnect();	
                                     	?>
                                </table>
                        </form>
                </div>	
                <div id="myModal" class="modal fade" role="dialog">
                  <div class="modal-dialog">

                    <!-- Modal content-->
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Editer le compte </h4>
                      </div>
                      <div class="modal-body">
                          <?php include("forms.php");?>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                    </div>

                  </div>
                </div>
