<?php 

function itemDesing($link,$title){
    echo "<li><a href='".$link."'><i class='glyphicon glyphicon-home'></i>".$title."</a></li>";
}


function PRINT_MENU(){ echo "<div class='menu-continer'>
       
            <header><span><i class='glyphicon glyphicon-th-list'></i>  Menu</span></header> 
            <ul>
                <li><a href=''><i class='glyphicon glyphicon-home'></i> Acceuil</a></li>
                <li><a href=''><i class='glyphicon glyphicon-list-alt'></i> ITEM2 TITLE</a></li>
                <li><a href=''><i class='glyphicon glyphicon-education'></i> ITEM3 TITLE</a></li>
                <li><a href=''><i class='glyphicon glyphicon-book'></i> ITEM4 TITLE</a></li>
                <li><a href=''><i class='glyphicon glyphicon-tasks'></i> ITEM5 TITLE</a></li>
            </ul>
</div>";

}
