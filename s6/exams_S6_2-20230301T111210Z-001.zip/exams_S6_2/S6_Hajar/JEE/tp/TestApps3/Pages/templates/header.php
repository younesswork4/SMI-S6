<?php
    
    function PRINT_HEADER($role,$path){
        echo "<header class='top-header'>
          <span><i class='glyphicon glyphicon-th-large' ></i> Gestion Parc Informatique</span>
            <span>
             <style>p{float:left;margin-right: 15px;margin-top: -1px;}</style>
                
             <p> <i class='glyphicon glyphicon-user'></i> ".$role."</p>
            	<a href='".$path."logout.php' style='color:red' class='glyphicon glyphicon-off logout-btn'></a> 
            </span>
        </header>";
    }

?>