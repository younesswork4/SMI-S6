<?php
session_start();
require_once '../../templates/template.php';
require_once('../../Auth.php');
require_once '../../../Database/database.php';
extract($_SESSION);
if (Auth::isLogged() == false) {
    Auth::redirectTo("../../login.php");
}
$param = array("Jforms","JSuppMat","JUpdate");

?>

<html>
    <head>
        <?php template::head($param);?>
    </head>
    <body>
        <?php template::getHeader($compte['nom']." ".$compte['prenom']);?>

        <div class="menu-continer">
           <?php 
                include("../AdminTemplate/menu_admin.php");
                getMenu("materiel");
            ?>
        </div>
        <div class="content-continer">
            <?php include("TemplateMateriel/content_listMateriel.php");?>
        </div>
       
    </body>
</html>