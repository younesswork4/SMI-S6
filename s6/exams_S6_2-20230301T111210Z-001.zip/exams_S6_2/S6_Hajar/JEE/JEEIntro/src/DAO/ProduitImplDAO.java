package DAO;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import Entity.Produit;
import Utils.DB;

public class ProduitImplDAO implements IProduitDAO {

	private DB db = null;

	public ProduitImplDAO() {

		db = new DB();

	}

	@Override
	public boolean AjouterProduit(Produit p) {

		try {

			String query = "insert into produit values(NULL,?,?,?,?)";

			Connection cn = db.Connect();

			PreparedStatement PStatement = (PreparedStatement) cn.prepareStatement(query);
			PStatement.setString(1, p.getDesignation());
			PStatement.setFloat(2, p.getPrix_achat());
			PStatement.setFloat(3, p.getPrix_vente());
			PStatement.setInt(4, p.getQteStock());

			PStatement.executeUpdate();

			cn.close();

			return true;

		} catch (Exception ex) {

			ex.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean ModifierProduit(Produit p) {
		try {

			String query = "update produit set designation=?,prix_achat=?,prix_vente=?,qteStock=? where id=?";

			Connection cn = db.Connect();

			PreparedStatement PStatement = (PreparedStatement) cn.prepareStatement(query);
			PStatement.setString(1, p.getDesignation());
			PStatement.setFloat(2, p.getPrix_achat());
			PStatement.setFloat(3, p.getPrix_vente());
			PStatement.setInt(4, p.getQteStock());
			PStatement.setInt(5, p.getID());

			PStatement.executeUpdate();

			cn.close();

			return true;

		} catch (Exception ex) {

			ex.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean SupprimerProduit(Integer id) {

		try {
			

			String query = "delete from produit where id = ?";

			Connection cn = db.Connect();

			PreparedStatement PStatement = (PreparedStatement) cn.prepareStatement(query);
			PStatement.setInt(1, id);
			PStatement.executeUpdate();

			cn.close();

			return true;

		} catch (Exception ex) {

			ex.printStackTrace();
		}

		return false;

	}

	@Override
	public List<Produit> getAllProduit() {

		List<Produit> ls = new ArrayList<Produit>();

		try {

			String query = "select * from produit";

			Connection cn = db.Connect();

			Statement statement = (Statement) cn.createStatement();

			ResultSet rs = statement.executeQuery(query);

			while (rs.next()) {

				Produit p = new Produit();
				p.setID(rs.getInt(1));
				p.setDesignation(rs.getString(2));
				p.setPrix_achat(rs.getFloat(3));
				p.setPrix_vente(rs.getFloat(4));
				p.setQteStock(rs.getInt(5));

				ls.add(p);
			}

			cn.close();

			return ls;

		} catch (Exception ex) {

			ex.printStackTrace();
		}

		return null;
	}

	@Override
	public Produit getProduitById(Integer id) {

		try {

			String query = "select * from produit where id = " + id;

			Connection cn = db.Connect();

			Statement statement = (Statement) cn.createStatement();

			ResultSet rs = statement.executeQuery(query);

			Produit p = new Produit();
			
			while (rs.next()) {

				
				p.setID(rs.getInt(1));
				p.setDesignation(rs.getString(2));
				p.setPrix_achat(rs.getFloat(3));
				p.setPrix_vente(rs.getFloat(4));
				p.setQteStock(rs.getInt(5));
			
			}

			cn.close();

			return p;

		} catch (Exception ex) {

			ex.printStackTrace();
		}

		return null;

	}

}
