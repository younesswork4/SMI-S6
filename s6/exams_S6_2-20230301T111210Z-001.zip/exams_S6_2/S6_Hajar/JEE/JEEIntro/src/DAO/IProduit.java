package DAO;

import java.util.List;

import Entity.Produit;

public interface IProduit {


	public boolean AjouterProduit(Produit p);
	public boolean ModifierProduit(Produit p);
	public boolean SupprimerProduit(Integer id);
	public List<Produit> getAllProduit();
	public Produit getProduitById(Integer id);
	
}
