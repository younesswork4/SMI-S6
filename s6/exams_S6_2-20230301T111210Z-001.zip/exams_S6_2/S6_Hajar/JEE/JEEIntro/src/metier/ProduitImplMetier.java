package metier;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

import DAO.ProduitImplDAO;
import Entity.Produit;
import Utils.DB;

public class ProduitImplMetier implements IProduitMetier {

	ProduitImplDAO produitDao;
	
	
	public ProduitImplMetier() {
		
		this.produitDao = new ProduitImplDAO();
	}
	
	@Override
	public boolean AjouterProduit(Produit p) {
		
	 return	this.produitDao.AjouterProduit(p);
		
		
	}

	@Override
	public boolean ModifierProduit(Produit p) {
	
	  return this.produitDao.ModifierProduit(p);
	  
	}

	@Override
	public boolean SupprimerProduit(Integer id) {
	
		return this.produitDao.SupprimerProduit(id);
	}

	@Override
	public List<Produit> getAllProduit() {
		
		return this.produitDao.getAllProduit();
	}

	@Override
	public Produit getProduitById(Integer id) {
		
		return this.produitDao.getProduitById(id);
	}

	

	

}
