package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Entity.Produit;
import metier.IProduitMetier;
import metier.ProduitImplMetier;

@WebServlet("/ListProduit")
public class ListProduit extends HttpServlet {
	
	IProduitMetier produitMetier;
	
	
	public ListProduit() {
		
		this.produitMetier = new ProduitImplMetier();
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Produit> ls = this.produitMetier.getAllProduit();
		
		String data = "<ul>";
		
		for (int i = 0; i < ls.size(); i++) {
			
			data += "<li>"+ls.get(i).getDesignation()+"</li>";
		}
		
		data += "</ul>";
		
		response.getWriter().append(data);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
