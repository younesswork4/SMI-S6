package Utils;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class DB {

	private Connection cn= null;
	private String user = "root";
	private String password= "devpart2015";
	private String host = "jdbc:mysql://localhost/jdbcS6?useSSL=false";
	
	public Connection Connect() {
		
		try {
			
		    Class.forName("com.mysql.jdbc.Driver");
		
	 	    cn =(Connection) DriverManager.getConnection(host,user,password);
	 	    
	 	    return cn;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
		
		
	}
	
	
	
	public void Disconnect() {
		
	}
	
	
	
}




