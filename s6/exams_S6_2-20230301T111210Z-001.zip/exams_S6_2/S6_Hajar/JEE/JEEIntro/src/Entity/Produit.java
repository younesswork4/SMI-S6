package Entity;

public class Produit {

	private Integer ID;
	private String designation;
	private Float prix_achat;
	private Float prix_vente;
	private Integer qteStock;

	public Produit() {

	}

	public Produit(String designation, Float prix_achat, Float prix_vente, Integer qteStock) {
		super();
		this.designation = designation;
		this.prix_achat = prix_achat;
		this.prix_vente = prix_vente;
		this.qteStock = qteStock;
	}

	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Float getPrix_achat() {
		return prix_achat;
	}

	public void setPrix_achat(Float prix_achat) {
		this.prix_achat = prix_achat;
	}

	public Float getPrix_vente() {
		return prix_vente;
	}

	public void setPrix_vente(Float prix_vente) {
		this.prix_vente = prix_vente;
	}

	public Integer getQteStock() {
		return qteStock;
	}

	public void setQteStock(Integer qteStock) {
		this.qteStock = qteStock;
	}

}
