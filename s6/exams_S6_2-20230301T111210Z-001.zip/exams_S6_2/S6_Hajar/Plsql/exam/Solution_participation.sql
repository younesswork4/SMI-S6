/*--Execrice 1--*/
create or replace procedure Add_Dept(V_deptno dept.deptno%TYPE,V_denqme dept.dename%TYPE,V_loc dept.loc%TYPE,)
is
begin 
	
	insert into dept(NumDept,dname,loc) values(V_deptno,V_dname,V_loc);
	
end;

/*--Execrice 2--*/
create or replace procedure Nb_Participation
is
	cursor emp_p is
	select e.Matr AS Matricule ,NomE,count(*) As nb_participation
	from emp e,participation p;
	where e.Matr = p.Matr
	group by e.Matr,NomE;
	
begin 

	for	c in emp_p loop
		DBMS_OUTPUT.PUT_LINE(c.Matricule||' '||c.NomE||' '||c.nb_participation);
	end loop;
	
end;

/*--Execrice 3--*/
Accept num_dept prompt 'Entre le numero de departement a supprimer : '
create or replace procedure Delete_Dept
is
	nbS Number(3);
begin 

	delete from dept where NumDept = v_NumDept;
	nbS:=SQL%ROWCOUNT; 
	DBMS_OUTPUT.PUT_LINE(nbS||' enregistrements affectés');
	
end;

/*--Execrice 4--*/
create table TOP_SALAIR(nom varchar2(30),sal Number(11,2));

Accept Nbem prompt 'Entre le numero de departement a supprimer : '
create or replace procedure TOP_SALAIRE
is
	v_sal emp.Salaire%TYPE;
	v_Nom emp.NomE%TYPE;
	cursor top_sal is 
	select NomE,Salaire from emp
	order by sal desc;
	having count(*)=&Nbemp;
	
begin 
	
	open top_sal;
	loop
		fetch top_sal into v_Nom,v_sal;
		Exit When top_sal%NOTFOUND OR top_sal%ROWCOUNT>&Nbemp;
		insert into TOP_SALAIR(nom,sal) values(v_Nom,v_sal);
	end loop;	
	close top_sal;
end;


/*--Execrice 5--*/
create table MESSAGES(Results varchar2(100));

create or replace procedure In_MESSAGE()
is
	v_NumDept dept.NumDept%TYPE;
	v_NomE 	  emp.NomE%TYPE;
	
	cursor dept_c is 
	select NumDept from dept order by NumDept;
	
	cursor emp_c(v_deptno NUMBER ) is 
	select NomE form emp
	where NumDept = v_deptno;
		
begin 
	
	open dept_c;
		loop
			fetch dept_c into v_NumDept;
			Exit When dept_c%NOTFOUND;
			open emp_c(v_NumDept);
				loop
					fetch emp_c into v_NomE;
					Exit When emp_c%NOTFOUND;
					insert into MESSAGES(Results) values(v_NomE||'-Departement-'||to_char(NumDept) );
				end loop;
			close emp_c;
			
		end loop;
	close dept_c;
	
end;


/*--Execrice 6--*/
create or replace procedure Test_10Part
is
	v_matr emp.matr%TYPE;
	v_emp emp%ROWTYPE;
	
begin 
	 
	select * into V_emp
	from emp e,participation p;
	where e.Matr = p.Matr
	group by e.Matr
	having count(*)=10;
	
	/*---------------affichage des informations emp-----*/
	DBMS_OUTPUT.PUT_LINE('matricule :'||v_emp.Matr||','||'Nom :'||v_emp.NomE||','||'Salaire :'||v_emp.Salaire||','
							||'Departement :'||v_emp.NumDept||'.');
  EXCEPTION
	    WHEN no_data_found THEN
			DBMS_OUTPUT.PUT_LINE('Il y''a aucun employer qui participe en 10 projets ');
	    WHEN too_many_rows THEN
	      	DBMS_OUTPUT.PUT_LINE('Plusieur employer qui participents en 10 projets ');

end;

/*--Execrice 7--*/
create or replace procedure Sal_emp(v_sal emp.Salaire%TYPE)
is
	v_nb_emp NUMBER(3);
	v_sal1 = emp.Salaire%TYPE:=v_sal-100;
	v_sal2 = emp.Salaire%TYPE:=v_sal+100;	
	ex exception;
begin 
	
		
	select count(*) into v_nb_emp from emp
	where Salaire BETWEEN v_sal1 AND v_sal2;
	if v_nb_emp = 0 then
		raise ex;
	else
		DBMS_OUTPUT.PUT_LINE(v_nb_emp||' employers dont le sal est comprie entre : '||v_sal1||' et '||v_sal2); 
	end if;
	
	EXCEPTION
	    When ex Then
			DBMS_OUTPUT.PUT_LINE('Il y''a aucun employer dont le sal est comprie entre : '||v_sal1||' et '||v_sal2);
	    When others Then
	      	DBMS_OUTPUT.PUT_LINE('Une menace est detecter !! ');
end;

/*--Execrice 9--*/

CREATE OR REPLACE PROCEDURE limitAcces
IS
BEGIN
  IF TO_CHAR (SYSDATE, 'HH24:MI') NOT BETWEEN '08:45' AND '17:30'
        OR TO_CHAR (SYSDATE, 'DY') IN ('SAT', 'SUN') THEN
	RAISE_APPLICATION_ERROR (-20205, 
		'Mode hors ligne !!');
  END IF;
END limitAcces;


CREATE OR REPLACE TRIGGER secure_donnee
  BEFORE INSERT OR UPDATE OR DELETE ON *
  BEGIN
    limitAcces;
  END secure_donnee;

  
/*--Execrice 10--*/

CREATE OR REPLACE PROCEDURE MESSAGES_ALERT
IS
	cursor emp_c is 
	select matr from participation
	where Fonction = 'chef de projet'
	group by matr
	having count(*)>5;
	
BEGIN
	open emp_c;
		if emp_c%NOTFOUND then 
			raise_application_error(-20205,'Il y''on a des employers qui on participer plus que 5 fois autant que chef de projet');
		end if;
	close emp_c;	
END;


CREATE OR REPLACE TRIGGER MSG_ALRT
  AFTER INSERT OR UPDATE OR DELETE ON *
  BEGIN
    MESSAGES_ALERT;
  END MSG_ALRT;





